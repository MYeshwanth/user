package com.cg.usermanagement.service;


import com.cg.ums.exception.UserException;
import com.cg.usermanagement.bean.AdminBean;
import com.cg.usermanagement.bean.UserBean;
import com.cg.usermanagement.dao.UserDaoImpl;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserServiceImpl implements IUser {

	UserBean bookbean = new UserBean();

	UserDaoImpl userdao = new UserDaoImpl();
	
	//------------------------ 1. User Management Role of Book-Store Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	CheckAdminDetails
			 - Input Parameters	:	UserBean bean2
			 - Return Type		:	boolean
			 - Throws			:  	SQLException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	24/06/2019
			 - Description		:	checking admin to database calls dao method CheckAdminDetails(UserBean bean)
			 ********************************************************************************************************/


	public boolean CheckAdminDetails(AdminBean bean) throws UserException, SQLException {
		
		boolean valid = false;
		try {
			String mailRegEx = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
					+ "A-Z]{2,7}$";
			String passwordRegEx = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";

			if (!Pattern.matches(mailRegEx, bean.getAdminEmail())) {
				valid = false;
				throw new UserException("Please enter a valid email address. Ex:username@abc.com");
			}
			if (!Pattern.matches(passwordRegEx, bean.getAdminPassword())) {
				valid = false;
				throw new UserException("Password should one digit from 0-9, one lower case letter,\"\r\n"
						+ " one upper case letter, one special symbol and atleast 6 characters and maximum of 20 characters");
			}

			
		} catch (UserException e) {
			System.out.println(e.getMessage());
		}
		valid = userdao.CheckAdminDetails(bean);

		return valid;
	}

	/*******************************************************************************************************
	 - Function Name	:	ViewUserListing()
	 - Input Parameters	:	No Input Parameters
	 - Return Type		:	List
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Retrieving all user details to database calls dao method ViewUserListing()
	 ********************************************************************************************************/

	
	public List<UserBean> ViewUserListing() throws UserException,Exception {
	

		return userdao.ViewUserListing();
	}

	/*******************************************************************************************************
	 - Function Name	:	SearchId
	 - Input Parameters	:	String id
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Searching ID to databse calls dao method SearchId(String id)
	 ********************************************************************************************************/

	
	public int SearchId(String id) throws Exception {
		int i = 0;

		Pattern idPattern = Pattern.compile("[0-9]{1,10}");
		Matcher idMatcher = idPattern.matcher(id);
		if (idMatcher.matches()) {
		

			i = userdao.SearchId(id);
			

		} else {
			throw new UserException("Enter numbers only");
		}
		return i;

	}

	/*******************************************************************************************************
	 - Function Name	:	AddNewUser
	 - Input Parameters	:	UserBean bean
	 - Return Type		:	String
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Adding New USer 
	 ********************************************************************************************************/

	public String AddNewUser(UserBean bean) throws Exception {
	

		String id=userdao.AddNewUser(bean);
		return id; 
	}

	/*******************************************************************************************************
	 - Function Name	:	EditUser
	 - Input Parameters	:	UserBean bean
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Updating/Editing User Details to database calls dao mthod EditUser(UserBean bean)
	 ********************************************************************************************************/

	
	public int EditUser(UserBean bean) throws Exception {


		int result=userdao.EditUser(bean);
		
		return result;
		
		
	}

	/*******************************************************************************************************
	 - Function Name	:	DeleteUser(UserBean bean)
	 - Input Parameters	:	UserBean bean
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Deleting/Removing User Details to database calls DAO method DeleteUser(UserBean bean) 
	 ********************************************************************************************************/

	public int DeleteUser(UserBean bean) throws Exception {

		int response=userdao.DeleteUser(bean);
		return response;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	ExistEmailOrNot(String email)
	 - Input Parameters	:	String email
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Checking Existing Emails  to database calls DAO method ExistEmailOrNot(String email) 
	 ********************************************************************************************************/

	public int ExistEmailOrNot(String email) throws SQLException, UserException {
		int response=userdao.ExistEmailOrNot(email);
		return response;
	}
	
	
	
	
	
	
	

	/*******************************************************************************************************
	 - Function Name	: ValidateEmail(String st)
	 - Input Parameters	: String st
	 - Return Type		: void
	 - Throws		    : UserException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the UserBean Mail
	 ********************************************************************************************************/

	public void ValidateEmail(String st) throws UserException {
		

		String mailRegEx = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";

		// String mailRegEx ="^[\\w.+\\-]+@gmail\\.com$";
		if (!Pattern.matches(mailRegEx, st)) {
			throw new UserException("Email pattern was wrong");
		}
	}

	/*******************************************************************************************************
	 - Function Name	: ValidateFullName(String name)
	 - Input Parameters	: String name
	 - Return Type		: void
	 - Throws		    : UserException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the UserBean FullName
	 ********************************************************************************************************/

	
	public void ValidateFullName(String name) throws UserException {
		
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,20}";
		// String nameRegEx ="^[A-Za-z\\s]+${4,10}";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new UserException("First letter should be capital and Length must be in between 5 to 20 \n");
		}
	}

	/*******************************************************************************************************
	 - Function Name	: ValidatePassword(String password1)
	 - Input Parameters	: String password1
	 - Return Type		: void
	 - Throws		    : UserException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the UserBean Password
	 ********************************************************************************************************/

	public void ValidatePassword(String password1) throws UserException {
		
		// String passwordRegEx ="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		String passwordRegEx = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
		if (!Pattern.matches(passwordRegEx, password1)) {
			throw new UserException("Password should one digit from 0-9, one lower case letter,"
					+ " one upper case letter, one special symbol and atleast 6 characters and maximum of 20 characters ");
		}
	}
}

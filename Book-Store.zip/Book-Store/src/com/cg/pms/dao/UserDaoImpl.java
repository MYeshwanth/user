package com.cg.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.pms.bean.UserBean;
import com.cg.pms.connection.DBConnection;

import com.cg.ums.exception.UserException;

public class UserDaoImpl implements IUserDao {

	UserBean bean = new UserBean();
	Scanner sc = new Scanner(System.in);

	Connection connection = DBConnection.getInstance().getConnection();

	PreparedStatement preparedStatement = null;

	ResultSet resultset = null;
	static Logger logger = Logger.getRootLogger();

	public UserDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	public boolean CheckAdminDetails(UserBean bean2) throws SQLException {
		boolean flag = false;

		preparedStatement = connection.prepareStatement(QueryMapper.LOGIN_QUERY);
		resultset = preparedStatement.executeQuery();
		while (resultset.next()) 
		{
			if (bean2.getAdminEmail().equalsIgnoreCase(resultset.getString(1))
					&& bean2.getAdminPassword().equals(resultset.getString(2))) {
				flag = true;
			}
		}
		return flag;

	}

	public List<UserBean> ViewUserListing() throws Exception {

		List<UserBean> UserList = new ArrayList<UserBean>();

		preparedStatement = connection.prepareStatement(QueryMapper.VIEW_DETAILS_QUERY);
		resultset = preparedStatement.executeQuery();

		while (resultset.next()) {
			UserBean bean = new UserBean();

			bean.setId(resultset.getString(2));
			bean.setMail(resultset.getString(3));
			bean.setFullName(resultset.getString(4));
			bean.setPassword(resultset.getString(5));
			UserList.add(bean);

		}
		return UserList;
	}

	public String AddNewUser(UserBean bean) throws Exception {
		String i = null;
		int queryResult = 0;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, bean.getMail());
			preparedStatement.setString(2, bean.getFullName());
			preparedStatement.setString(3, bean.getPassword());

			queryResult = preparedStatement.executeUpdate();
			if (queryResult == 0) {

				logger.error("Insertion failed ");

				throw new UserException("Inserting donor details failed ");

			} else {
				logger.info("Successfully created new user");
				preparedStatement = connection.prepareStatement(QueryMapper.SEQ_ID_QUERY);
				resultset = preparedStatement.executeQuery();

				while (resultset.next()) {
					i = resultset.getString(1);

				}

			}
		} catch (SQLException sqlException) {

			logger.error(sqlException.getMessage());

		} finally {
			try {

				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new UserException("Error in closing db connection");

			}
		}
		return i;

	}

	public int SearchId(String id) throws Exception {
		int res = 0;

		preparedStatement = connection.prepareStatement(QueryMapper.SEARCH_QUERY);
		preparedStatement.setString(1, id);
		resultset = preparedStatement.executeQuery();

		if (resultset.next()) {

			res = 1;

		} else {
			System.out.println("No records with given ID");
			res = 0;
		}
		return res;
	}

	public void EditUser(UserBean bean) throws Exception {

		int queryresult = 0;

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_QUERY);
			System.out.println("Enter email to update");

			preparedStatement.setString(1, sc.next());
			System.out.println("Enter Full name to update");
			preparedStatement.setString(2, sc.next());

			System.out.println("Enter password to update");
			preparedStatement.setString(3, sc.next());
			preparedStatement.setString(4, bean.getId());

			System.out.println("Do you want to update the details mentioned above Yes/No");
			String answer = sc.next();
			if (answer.equalsIgnoreCase("yes")) {
				queryresult = preparedStatement.executeUpdate();
				if (queryresult != 0) {
					logger.info("Successfully updated your details");
				} else {
					logger.error("Updation failed ");
					throw new UserException("Updating user details failed ");
				}

			} else {
				System.exit(0);
			}
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new UserException("Tehnical problem occured refer log");
		}
	}

	public int DeleteUser(UserBean bean) throws Exception {

		int queryresult = 0;

		try {

			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_QUERY);
			preparedStatement.setString(1, bean.getId());
			queryresult = preparedStatement.executeUpdate();
			/*
			 * if (queryresult == 0) { logger.error("Deletion failed "); throw new
			 * UserException("Deleting user details failed ");
			 * 
			 * } else { logger.info("Successfully deleted your details"); }
			 */

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new UserException("Tehnical problem occured refer log");
		}
		return queryresult;
	}
}
//}
package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.bean.UserBean;

public interface IUserDao {

	public List<UserBean> ViewUserListing() throws Exception;
	
	public String AddNewUser(UserBean bean) throws Exception;
	
	public int EditUser(UserBean bean) throws Exception;
	
	public int DeleteUser(UserBean bean) throws Exception;
}

package com.cg.pms.dao;



public interface QueryMapper {
	
	public static final String VIEW_DETAILS_QUERY="SELECT * FROM BOOKSTORE ORDER BY FULLNAME ";
	
	public static final String INSERT_QUERY="INSERT INTO BOOKSTORE values(indexnum_seq.nextval,ID_seq.nextval,?,?,?)";
	
	public static final String UPDATE_QUERY="UPDATE BOOKSTORE SET EMAIL=?,FULLNAME=?,PASSWORD=? WHERE ID=?";
	
	public static final String DELETE_QUERY="DELETE FROM BOOKSTORE WHERE ID=?";
	
	public static final String LOGIN_QUERY="SELECT * FROM ADMIN_DETAILS";
	
	public static final String SEARCH_QUERY="SELECT * FROM BOOKSTORE WHERE ID=?";
	
	public static final String SEQ_ID_QUERY="SELECT ID_SEQ.CURRVAL FROM DUAL";
	
	public static final String EMAILEXISTORNOT_QUERY="SELECT EMAIL FROM BOOKSTORE";
}

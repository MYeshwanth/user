package com.cg.pms.connection;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class DBConnection {
    
	private static Connection conn = null;
	private static DBConnection instance = null;
	private static Properties props = null;
	
	private static OracleDataSource dataSource = null;
	public DBConnection()//private constructor
	{
		try {
			props = loadProperties();
			try {
				dataSource = prepareDataSource();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
 
	}
	private Properties loadProperties() throws IOException {
 
		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "resources/jdbc.properties";
 
			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);
 
			inputStream.close();
 
			return newProps;
		} else {
			return props;
		}
	}
	private OracleDataSource prepareDataSource() throws SQLException {
 
		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("dburl");
				String username = props.getProperty("username");
				String password = props.getProperty("password");
 
				dataSource = new OracleDataSource();
 
				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
	public static DBConnection getInstance() //singleton class
	{
		synchronized (DBConnection.class) {
			if (instance == null) {
				instance = new DBConnection();
			}
		}
		return instance;
	}
	public Connection getConnection() {
		try {
 
			conn = dataSource.getConnection();
 
		} catch (SQLException e) {
			System.out.println(e);
			//throw new DonorException(" Database connection problem");
		}
		return conn;
	}
	
	
	
	
	
	
   
	/*
	 * public Connection getConnection() throws Exception { try {
	 * 
	 * //connection.setAutoCommit(true); Class.forName("oracle.jdbc.OracleDriver");
	 * connection
	 * =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system",
	 * "9999");
	 * 
	 * } catch(Exception e) { System.out.println(e); } return connection;
	 * 
	 * }
	 * 
	 */
}


package com.cg.pms.bean;

public class UserBean {

	private String Mail;
	private String FullName;
	private String Password;
	private String Id;
	private String AdminEmail;
	private String AdminPassword;
	
	
	public UserBean()
	{
		
	}
	
	public String getMail() {
		return Mail;
	}

	public void setMail(String mail) {
		Mail = mail;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getAdminEmail() {
		return AdminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		AdminEmail = adminEmail;
	}

	public String getAdminPassword() {
		return AdminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		AdminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return "UserBean [Mail=" + Mail + ", \tFullName=" + FullName + ", \tPassword=" + Password + ", \tId=" + Id + "]";
	}

	
	
	/*
	 * public UserBean(String email,String fname,String password) { super();
	 * this.email=email; this.fname=fname; this.password=password; }
	 */
	
	
}

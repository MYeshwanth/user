package com.cg.pms.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.pms.bean.UserBean;
import com.cg.ums.exception.UserException;

public interface IUser {

	public List<UserBean> ViewUserListing() throws Exception;
	
	public int DeleteUser(UserBean bean) throws Exception;
	
	public void EditUser(UserBean bean) throws Exception;
	
	public String AddNewUser(UserBean bean) throws Exception;
	
	public void ValidateEmail(String st) throws UserException;
	
	public void ValidateFullName(String name) throws UserException;
	
	public void ValidatePassword(String password1) throws UserException;
	
	public int SearchId(String id) throws Exception;
	
	public boolean CheckAdminDetails(UserBean bean) throws UserException, SQLException;
}

package com.cg.ums.test;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.pms.bean.AdminBean;
import com.cg.pms.bean.UserBean;
import com.cg.pms.dao.UserDaoImpl;



public class UserDaoTest {

	static UserDaoImpl dao;
	static UserBean user;
	
	@Test
	public void testIDverification() throws Exception
	{
		UserBean user = new UserBean();
		UserDaoImpl dao=new UserDaoImpl();
		user.setId("154");
		assertEquals(1,dao.SearchId("154"));
	}
	@Test
	public void testDeleteUser() throws Exception{
		UserBean user = new UserBean();
		UserDaoImpl dao=new UserDaoImpl();
		user.setId("30");
		
		assertEquals(0,dao.DeleteUser(user));
	 
	}
	
	@Test
	public void testEditUser() throws Exception {
		UserBean user = new UserBean();
		UserDaoImpl dao = new UserDaoImpl();
		user.setMail("macha@gmail.com");
		user.setFullName("Suresh");
		user.setPassword("Yeshu12345$");
		user.setId("20");
		assertEquals(0, dao.EditUser(user));
	} 
	
	@Test
	public void testLoginCheck() throws Exception {
		AdminBean admin = new AdminBean();
		UserDaoImpl dao = new UserDaoImpl();
		admin.setAdminEmail("suresh@gmail.com");
		admin.setAdminPassword("Suresh@123");
		assertEquals(false, dao.CheckAdminDetails(admin));

	}
	 
	/*
	 * @BeforeClass public static void initialize() {
	 * System.out.println("in before class"); dao = new UserDaoImpl(); user = new
	 * UserBean(); }
	 * 
	 * @Test public void testNewUSer() throws Exception { // increment the number
	 * next time you test for positive test case UserBean user = new UserBean();
	 * UserDaoImpl dao=new UserDaoImpl(); user.setMail("ram10@gmail.com");
	 * user.setFullName("Rama"); user.setPassword("Ram@123"); String
	 * returnnum=dao.AddNewUser(user); int num=Integer.parseInt(returnnum);
	 * System.out.println(num); assertEquals(154,num ); }
	 * 
	 * @Test public void testIDverification() throws Exception { UserBean user = new
	 * UserBean(); UserDaoImpl dao=new UserDaoImpl();
	 * 
	 * assertEquals(1,dao.SearchId("149")); }
	 * 
	 * UserDaoImpl daoImpl=null;
	 * 
	 * @Before public void setUp() throws Exception { daoImpl = new UserDaoImpl(); }
	 * 
	 * @After public void tearDown() throws Exception { daoImpl = null; }
	 */
	/*
	 * @Test public void testaddnewuser() throws Userexception {
	 * 
	 * assertNotNull(dao.addnewuser(user));
	 * 
	 * }
	 * 
	 * @Ignore
	 * 
	 * @Test public void testaddnewuser1() throws Userexception {
	 * 
	 * assertEquals(dao.addnewuser(user)); }
	 */
	
	

	//@Test
	/*
	 * public void testAddnewuser() throws Exception { UserBean ub=new UserBean();
	 * try { String genId = daoImpl.addnewuser(ub); assertNotNull(genId); }
	 * catch(UserException e) {
	 * 
	 * } }
	 */
	 
	/*
	 * @Test public void testViewallusers() throws Exception {
	 * 
	 * try { daoImpl.viewuserlisting(); //assertTrue(list.size() > 0); } catch
	 * (UserException e) {
	 * 
	 * } }
	 */
}
